package com.practicalhomeapp.ecolibriumreef;

public interface BluetoothConstants {

    // Constants used between BluetoothService and MainActivity
    String MSG_BT_NO_PAIRED_DEVICE = "bt_no_paired_device";
    String MSG_BT_STATE_CHANGE = "bt_state_change";
    String MSG_BT_READ = "bt_read";

    int STATE_BT_NOT_CONNECTED = 20;
    int STATE_BT_LISTENING = 21;
    int STATE_BT_CONNECTING = 22;
    int STATE_BT_CONNECTION_FAILED = 23;
    int STATE_BT_CONNECTED = 24;
    int STATE_BT_CONNECTION_LOST = 25;
}
