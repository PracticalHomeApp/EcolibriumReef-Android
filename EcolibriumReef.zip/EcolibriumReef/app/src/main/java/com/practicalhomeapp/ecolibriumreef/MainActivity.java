package com.practicalhomeapp.ecolibriumreef;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.practicalhomeapp.ecolibriumreef.databinding.ActivityMainBinding;

import java.util.Calendar;

import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.MSG_BT_NO_PAIRED_DEVICE;
import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.MSG_BT_READ;
import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.STATE_BT_CONNECTED;

public class MainActivity extends AppCompatActivity {

    //public static final String TAG = "MainActivity";

    //*** Bluetooth
    private static final int REQUEST_ENABLE_BT = 101;
    private static final String mRemoteBluetoothDeviceName = "HC-05";
    private BluetoothService mBluetoothService = null;
    private static int BluetoothReconnectCount = 0;

    //*** Communication constants
    private static final byte COMMAND_INITIAL_SYNCH = 127;
    private static final byte COMMAND_ATO_ENABLE = 126;
    private static final byte COMMAND_ATO_DISABLE = 125;
    private static final byte COMMAND_ATO_BYPASS_ENABLE = 124;
    private static final byte COMMAND_ATO_BYPASS_DISABLE = 123;
    private static final byte COMMAND_SET_ATO_MAX_DURATION = 122;
    private static final byte COMMAND_SET_ATO_BYPASS_DURATION = 121;
    private static final byte COMMAND_TEST_MODE_ENABLE = 120;
    private static final byte COMMAND_TEST_MODE_DISABLE = 119;
    private static final byte COMMAND_TEST = 118;

    //*** Variables
    private int atoMaxDuration = 0;
    private boolean isAtoMaxNumberPickerScrolling = false;
    private int atoBypassDuration = 0;
    private boolean isAtoBypassNumberPickerScrolling = false;
    private byte switchesStates = 0;        // binary coded decimal
    // bit 0 - light white
    // bit 1 - light blue
    // bit 2 - fan 1
    // bit 3 - fan 2
    // bit 4 - valve 1
    // bit 5 - valve 2
    // bit 6 - valve 3
    // bit 7 - valve 4

    private final BroadcastReceiver btBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null) {
                switch (action) {
                    case BluetoothDevice.ACTION_ACL_CONNECTED:
                        //screenMessage(R.string.status_bt_connected);
                        btConnected();      // bluetooth connected, enable switches and number pickers
                        BluetoothReconnectCount = 0;
                        break;
                    case BluetoothDevice.ACTION_ACL_DISCONNECTED:
                        // try to reconnect 10 times
                        if (BluetoothReconnectCount < 10) {
                            //screenMessage(R.string.status_bt_reconnect);
                            connectBluetoothDevice();
                            BluetoothReconnectCount++;
                        }
                        else {
                            screenMessage(R.string.status_bt_connection_failed);
                            btDisconnected();   // bluetooth disconnected, disable switches and number pickers
                            BluetoothReconnectCount = 0;
                        }
                        break;
                    case MSG_BT_NO_PAIRED_DEVICE:
                        screenMessage(R.string.status_bt_no_paired_device);
                        break;
                    case MSG_BT_READ:
                        byte[] btData = intent.getByteArrayExtra("bluetooth_data");
                        receivedData(btData);
                        break;
                    default:
                }
            }
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.bluetooth_searching) {
            connectBluetoothDevice();
            return true;
        }
        else {
            return super.onOptionsItemSelected(item);
        }
    }

    private ActivityMainBinding activityMainBinding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        activityMainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = activityMainBinding.getRoot();
        setContentView(view);

        activityMainBinding.switchAto.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { sendData(COMMAND_ATO_ENABLE); }
                else { sendData(COMMAND_ATO_DISABLE); }
            }
        });

        activityMainBinding.switchAtoBypass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { sendData(COMMAND_ATO_BYPASS_ENABLE); }
                else { sendData(COMMAND_ATO_BYPASS_DISABLE); }
            }
        });

        activityMainBinding.numberPickerAtoMaxDuration.setMaxValue(60);
        activityMainBinding.numberPickerAtoMaxDuration.setEnabled(false);
        activityMainBinding.numberPickerAtoMaxDuration.setOnScrollListener(new NumberPicker.OnScrollListener() {
            @Override
            public void onScrollStateChange(NumberPicker numberPicker, int scrollState) {
                switch (scrollState) {
                    case NumberPicker.OnScrollListener.SCROLL_STATE_FLING:
                    case NumberPicker.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
                        isAtoMaxNumberPickerScrolling = true;       // when user starts scrolling, set flag and wait until it stops
                        break;
                    case NumberPicker.OnScrollListener.SCROLL_STATE_IDLE:
                        if (isAtoMaxNumberPickerScrolling) {
                            atoMaxDuration = numberPicker.getValue();
                            sendData(COMMAND_SET_ATO_MAX_DURATION);
                            isAtoMaxNumberPickerScrolling = false;
                        }
                        break;
                    default:
                }
            }
        });

        activityMainBinding.numberPickerAtoBypassDuration.setMaxValue(90);
        activityMainBinding.numberPickerAtoBypassDuration.setEnabled(false);
        activityMainBinding.numberPickerAtoBypassDuration.setOnScrollListener(new NumberPicker.OnScrollListener() {
            @Override
            public void onScrollStateChange(NumberPicker numberPicker, int scrollState) {
                switch (scrollState) {
                    case NumberPicker.OnScrollListener.SCROLL_STATE_FLING:
                    case NumberPicker.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
                        isAtoBypassNumberPickerScrolling = true;    // when user starts scrolling, set flag and wait until it stops
                        break;
                    case NumberPicker.OnScrollListener.SCROLL_STATE_IDLE:
                        if (isAtoBypassNumberPickerScrolling) {
                            atoBypassDuration = numberPicker.getValue();
                            sendData(COMMAND_SET_ATO_BYPASS_DURATION);
                            isAtoBypassNumberPickerScrolling = false;
                        }
                        break;
                    default:
                }
            }
        });

        activityMainBinding.switchTestMode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    sendData(COMMAND_TEST_MODE_ENABLE);
                    activityMainBinding.layout4.setVisibility(View.VISIBLE);
                    activityMainBinding.layout5.setVisibility(View.VISIBLE);

                    // When test mode is enabled, disable other controls
                    activityMainBinding.switchAto.setEnabled(false);
                    activityMainBinding.switchAtoBypass.setEnabled(false);
                    activityMainBinding.numberPickerAtoMaxDuration.setEnabled(false);
                    activityMainBinding.numberPickerAtoBypassDuration.setEnabled(false);
                }
                else {
                    sendData(COMMAND_TEST_MODE_DISABLE);
                    activityMainBinding.switchWhiteLight.setChecked(false);
                    activityMainBinding.switchBlueLight.setChecked(false);
                    activityMainBinding.switchFan1.setChecked(false);
                    activityMainBinding.switchFan2.setChecked(false);
                    activityMainBinding.switchValve1.setChecked(false);
                    activityMainBinding.switchValve2.setChecked(false);
                    activityMainBinding.switchValve3.setChecked(false);
                    activityMainBinding.switchValve4.setChecked(false);

                    activityMainBinding.layout4.setVisibility(View.INVISIBLE);
                    activityMainBinding.layout5.setVisibility(View.INVISIBLE);

                    // When test mode is disabled, enable other controls
                    activityMainBinding.switchAto.setEnabled(true);
                    activityMainBinding.switchAtoBypass.setEnabled(true);
                    activityMainBinding.numberPickerAtoMaxDuration.setEnabled(true);
                    activityMainBinding.numberPickerAtoBypassDuration.setEnabled(true);
                }
            }
        });

        activityMainBinding.switchWhiteLight.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { switchesStates |= 0b00000001; }
                else { switchesStates &= 0b11111110; }
                sendData(COMMAND_TEST);
            }
        });

        activityMainBinding.switchBlueLight.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { switchesStates |= 0b00000010; }
                else { switchesStates &= 0b11111101; }
                sendData(COMMAND_TEST);
            }
        });

        activityMainBinding.switchFan1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { switchesStates |= 0b00000100; }
                else { switchesStates &= 0b11111011; }
                sendData(COMMAND_TEST);
            }
        });

        activityMainBinding.switchFan2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { switchesStates |= 0b00001000; }
                else { switchesStates &= 0b11110111; }
                sendData(COMMAND_TEST);
            }
        });

        activityMainBinding.switchValve1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { switchesStates |= 0b00010000; }
                else { switchesStates &= 0b11101111; }
                sendData(COMMAND_TEST);
            }
        });

        activityMainBinding.switchValve2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { switchesStates |= 0b00100000; }
                else { switchesStates &= 0b11011111; }
                sendData(COMMAND_TEST);
            }
        });

        activityMainBinding.switchValve3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { switchesStates |= 0b01000000; }
                else { switchesStates &= 0b10111111; }
                sendData(COMMAND_TEST);
            }
        });

        activityMainBinding.switchValve4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { switchesStates |= 0b10000000; }
                else { switchesStates &= 0b01111111; }
                sendData(COMMAND_TEST);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();

        // Setup filter and register broadcast receiver
        // because BluetoothDevice.ACTION_ACL_DISCONNECTED is used, LocalBroadcastManager cannot be used
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        filter.addAction(MSG_BT_NO_PAIRED_DEVICE);
        filter.addAction(MSG_BT_READ);
        registerReceiver(btBroadcastReceiver, filter);

        // setup Bluetooth device and connect
        BluetoothAdapter mLocalBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mLocalBluetoothAdapter.isEnabled()) {
            connectBluetoothDevice();
        }
        else {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        connectBluetoothDevice();
    }

    @Override
    public void onPause() {
        super.onPause();

        disconnectBluetoothDevice();
    }

    @Override
    public void onStop() {
        super.onStop();
        disconnectBluetoothDevice();
        unregisterReceiver(btBroadcastReceiver);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        disconnectBluetoothDevice();    // calling disconnect just in case
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                connectBluetoothDevice();
            }
            else {
                // User did not enable Bluetooth or an error occurred
                screenMessage(R.string.status_bt_not_enabled);
            }
        }
        else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void connectBluetoothDevice() {
        if (mBluetoothService == null) {
            mBluetoothService = new BluetoothService(this, mRemoteBluetoothDeviceName);
            mBluetoothService.start();
        }
        if (mBluetoothService.getState() == STATE_BT_CONNECTED) {
            screenMessage(R.string.status_bt_already_connected);
        }
        else {
            screenMessage(R.string.status_bt_connecting);
            mBluetoothService.connect();
        }
    }

    public void disconnectBluetoothDevice() {
        if (mBluetoothService != null) {
            mBluetoothService.disconnect();
            mBluetoothService = null;
        }
    }

    public void sendByte(byte oneByte) {
        if (mBluetoothService != null) mBluetoothService.write(oneByte);
    }

    private void btConnected () {
        synchControls(true);
        sendData(COMMAND_INITIAL_SYNCH);
    }

    private void btDisconnected() {
        synchControls(false);
        disconnectBluetoothDevice();
    }

    private void synchControls(boolean state) {
        activityMainBinding.switchAto.setEnabled(state);
        activityMainBinding.switchAtoBypass.setEnabled(state);
        activityMainBinding.numberPickerAtoMaxDuration.setEnabled(state);
        activityMainBinding.numberPickerAtoBypassDuration.setEnabled(state);
        activityMainBinding.switchTestMode.setEnabled(state);
    }

    private void sendData(byte command) {
        Calendar c = Calendar.getInstance();

        sendByte(command);
        sendByte((byte) atoMaxDuration);
        sendByte((byte) atoBypassDuration);
        sendByte(switchesStates);
        sendByte((byte)(c.get(Calendar.YEAR) - 1970));
        sendByte((byte)(c.get(Calendar.MONTH) + 1));
        sendByte((byte) c.get(Calendar.DAY_OF_MONTH));
        sendByte((byte) c.get(Calendar.HOUR_OF_DAY));
        sendByte((byte) c.get(Calendar.MINUTE));
        sendByte((byte) c.get(Calendar.SECOND));
    }

    private void receivedData(byte[] buffer) {
        if (buffer[0] == buffer[27]) {
            // ato button state DISABLED/ENABLED 0/1
            if (buffer[1] == 0) activityMainBinding.switchAto.setChecked(false);
            else activityMainBinding.switchAto.setChecked(true);
            // ato bypass button state OFF/ON/DONE 0/1/2
            if (buffer[2] == 0) activityMainBinding.switchAtoBypass.setChecked(false);
            else activityMainBinding.switchAtoBypass.setChecked(true);

            atoMaxDuration = buffer[3];             // do not update during scrolling
            if (!isAtoMaxNumberPickerScrolling) activityMainBinding.numberPickerAtoMaxDuration.setValue(atoMaxDuration);

            atoBypassDuration = buffer[4];          // do not update during scrolling
            if (!isAtoBypassNumberPickerScrolling) activityMainBinding.numberPickerAtoBypassDuration.setValue(atoBypassDuration);

            activityMainBinding.textViewPH.setText(to_str(buffer, 5, 7));

            activityMainBinding.textViewWaterTemperature.setText(to_str(buffer, 8, 14));

            activityMainBinding.textViewAirTemperature.setText(to_str(buffer, 15, 21));

            activityMainBinding.textViewHumidity.setText(to_str(buffer, 22, 26));
        }
    }

    private String to_str(byte[] buffer, int start, int end) {
        // Format character sequence into string
        StringBuilder sb = new StringBuilder();
        for (int i = start; i <= end; i++) {
            sb.append(String.format("%c", buffer[i] & 0xff));
        }
        return sb.toString();
    }

    private void screenMessage(int msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

}