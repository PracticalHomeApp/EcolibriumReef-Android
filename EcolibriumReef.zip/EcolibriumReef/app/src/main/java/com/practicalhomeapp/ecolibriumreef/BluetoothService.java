package com.practicalhomeapp.ecolibriumreef;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import android.content.Context;
import android.content.Intent;
import android.os.ParcelUuid;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;

import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.MSG_BT_NO_PAIRED_DEVICE;
import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.MSG_BT_STATE_CHANGE;
import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.MSG_BT_READ;

import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.STATE_BT_NOT_CONNECTED;
import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.STATE_BT_CONNECTING;
import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.STATE_BT_CONNECTION_FAILED;
import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.STATE_BT_CONNECTED;
import static com.practicalhomeapp.ecolibriumreef.BluetoothConstants.STATE_BT_CONNECTION_LOST;

public class BluetoothService {
    private static final String TAG = "BluetoothService";

    // Member fields
    private final Context mContext;
    private final String mRemoteBluetoothDeviceName;
    private final BluetoothAdapter mLocalBluetoothAdapter;

    private ConnectBluetoothSocket mConnectBluetoothSocket = null;
    private ConnectedThread mConnectedThread = null;
    private int mState;

    public BluetoothService(Context context, String remoteDeviceName) {
        mContext = context;
        mRemoteBluetoothDeviceName = remoteDeviceName;
        mLocalBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        stateChanged(STATE_BT_NOT_CONNECTED);
    }

    private synchronized void stateChanged(int state) {
        // set bBluetooth state and send notification to UI
        mState = state;

        Intent bluetoothServiceBroadcastIntent = new Intent();
        bluetoothServiceBroadcastIntent.setAction(MSG_BT_STATE_CHANGE);
        bluetoothServiceBroadcastIntent.putExtra("bluetooth_connection_state", mState);
        mContext.sendBroadcast(bluetoothServiceBroadcastIntent);
    }

    public int getState() {
        return mState;
    }

    public synchronized void start() {
        resetBluetoothService();
    }

    private void resetBluetoothService () {
        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }
        if (mConnectBluetoothSocket != null) {
            mConnectBluetoothSocket.cancel();
            mConnectBluetoothSocket = null;
        }
    }

    public synchronized void connect() {
        stateChanged(STATE_BT_CONNECTING);
        resetBluetoothService();

        Set<BluetoothDevice> btPairedDevices = mLocalBluetoothAdapter.getBondedDevices();
        if (btPairedDevices.size() == 0) {
            Intent bluetoothServiceBroadcastIntent = new Intent();
            bluetoothServiceBroadcastIntent.setAction(MSG_BT_NO_PAIRED_DEVICE);
            mContext.sendBroadcast(bluetoothServiceBroadcastIntent);
        }
        else {
            for (BluetoothDevice device : btPairedDevices) {
                if (device.getName().equals(mRemoteBluetoothDeviceName)) {
                    // Get remote device MAC address
                    BluetoothDevice remoteBluetoothDevice = mLocalBluetoothAdapter.getRemoteDevice(device.getAddress());
                    // Attempt to connect to remote device
                    mConnectBluetoothSocket = new ConnectBluetoothSocket(remoteBluetoothDevice);
                    mConnectBluetoothSocket.start();
                    break;
                }
            }
        }
    }

    private synchronized void connected(BluetoothSocket socket) {
        resetBluetoothService();

        mConnectedThread = new ConnectedThread(socket);
        mConnectedThread.start();
    }

    public synchronized void disconnect() {
        stateChanged(STATE_BT_CONNECTION_LOST);

        resetBluetoothService();
    }

    public void write(byte out) {
        if (mState == STATE_BT_CONNECTED) {
            // Synchronize a copy of the ConnectedThread
            synchronized (this) {
                // Create temporary object and perform the write un-synchronized
                ConnectedThread tempConnectedThread = mConnectedThread;
                tempConnectedThread.write(out);
            }
        }
    }

    private class ConnectBluetoothSocket extends Thread {
        private final BluetoothSocket mSocket;

        private ConnectBluetoothSocket(BluetoothDevice remoteDevice) {
            BluetoothSocket tmpSocket = null;

            stateChanged(STATE_BT_CONNECTING);
            ParcelUuid[] uuids = remoteDevice.getUuids();
            try { tmpSocket = remoteDevice.createRfcommSocketToServiceRecord(uuids[0].getUuid()); }
            catch (IOException e) { Log.e(TAG, "createRfcommSocketToServiceRecord() failed", e); }
            mSocket = tmpSocket;
        }

        public void run() {
            // Cancel discovery because it will slow down a connection
            mLocalBluetoothAdapter.cancelDiscovery();

            // Connect BluetoothSocket
            // This is a blocking call and will only return on a successful connection or an exception
            try { mSocket.connect(); }
            catch (IOException e) {
                Log.e(TAG, "mSocket.connect() failed", e);

                try { mSocket.close(); }
                catch (IOException e2) { Log.e(TAG, "mSocket.close() failed", e2); }

                stateChanged(STATE_BT_CONNECTION_FAILED);
                return;
            }

            // Reset the ConnectBluetoothSocket because we're done
            synchronized (BluetoothService.this) { mConnectBluetoothSocket = null; }

            // Start the connected thread
            connected(mSocket);
        }

        private void cancel() {
            try { mSocket.close(); }
            catch (IOException e) { Log.e(TAG, "mSocket.close() failed", e); }
        }
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        private ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            }
            catch (IOException e) {
                Log.e(TAG, "socket.getInputStream() / socket.getOutputStream() failed", e);
                stateChanged(STATE_BT_CONNECTION_FAILED);
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;

            stateChanged(STATE_BT_CONNECTED);
        }

        public void run() {
            byte[] mmBuffer = new byte[32];                 // Change buffer size if needed
            int bytesRead;

            while (mState == STATE_BT_CONNECTED) {          // Keep listening to the InputStream while connected
                try {
                    if (mmInStream.available() >= 28) {     // expect 28 bytes from Arduino
                        //      1 byte - command start
                        //      1 byte - auto top-off state
                        //      1 byte - auto top-off bypass state
                        //      1 byte - ato max duration
                        //      1 byte - ato bypass max duration
                        //      3 bytes - pH
                        //      7 bytes - water temperature (e.g. 80.00°F)
                        //      7 bytes - air temperature   (e.g. 70.00°F)
                        //      5 bytes - humidity          (e.g. 40.0%)
                        //      1 byte - command end

                        bytesRead = mmInStream.read(mmBuffer);
                        Intent bluetoothServiceBroadcastIntent = new Intent();
                        bluetoothServiceBroadcastIntent.setAction(MSG_BT_READ);
                        //bluetoothServiceBroadcastIntent.putExtra("bluetooth_bytes_read", bytesRead);
                        bluetoothServiceBroadcastIntent.putExtra("bluetooth_data", mmBuffer);
                        mContext.sendBroadcast(bluetoothServiceBroadcastIntent);
                    }
                }
                catch (IOException e) {
                    Log.e(TAG, "mmInStream.read() failed", e);
                    stateChanged(STATE_BT_CONNECTION_LOST);
                    break;
                }
            }
        }

        private void write(byte b) {
            if (mState == STATE_BT_CONNECTED) {
                try {
                    mmOutStream.write(b);
                }
                catch (IOException e) {
                    Log.e(TAG, "mmOutStream.write() failed", e);
                    stateChanged(STATE_BT_CONNECTION_LOST);
                }
            }
        }

        private void cancel() {
            try { mmInStream.close(); }
            catch (IOException e) { Log.e(TAG, "mmInStream.close() failed", e); }

            try { mmOutStream.close(); }
            catch (IOException e) { Log.e(TAG, "mmOutStream.close() failed", e); }

            try { mmSocket.close(); }
            catch (IOException e) { Log.e(TAG, "mmSocket.close() failed", e); }
        }
    }
}

